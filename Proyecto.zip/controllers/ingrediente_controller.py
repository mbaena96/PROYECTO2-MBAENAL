from models.ingrediente import Ingrediente
from flask import Blueprint, render_template, flash, redirect, url_for
from db import db

ingrediente_bp = Blueprint('ingrediente_bp', __name__, url_prefix='/ingrediente')

@ingrediente_bp.route('/<int:id>')
def mostrar_ingredientes(id):
    ingrediente = Ingrediente.query.get(id)
    return render_template('ingrediente.html', ingrediente=ingrediente)

@ingrediente_bp.route('renovar/<int:id>')
def renovar_id(id):
    ingrediente = Ingrediente.query.get(id)
    ingrediente.renovar_inventario()
    db.session.commit()
    flash('Inventario renovado')
    return redirect(url_for('producto_bp.listar_productos'))
    